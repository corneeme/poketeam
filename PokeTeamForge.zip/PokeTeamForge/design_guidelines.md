# Pokémon Team Builder - Design Guidelines

## Design Approach

**Selected Approach:** Design System with Gaming Aesthetics
- Base: Material Design principles for clean data organization
- Enhancement: Pokémon gaming UI conventions (card-based, type colors)
- Inspiration: Pokémon Showdown's team builder + modern web app patterns

**Core Principle:** Information clarity with playful gaming touches

---

## Typography

**Font Stack:**
- Primary: Inter or Roboto via Google Fonts
- Headings: 600-700 weight
- Body: 400-500 weight
- Labels/Meta: 500 weight, all caps with letter-spacing

**Hierarchy:**
- Page titles: text-2xl to text-3xl
- Section headers: text-xl
- Card titles: text-lg
- Body/labels: text-sm to text-base
- Meta info (power/accuracy): text-xs

---

## Layout System

**Spacing Units:** Tailwind 2, 4, 6, 8, 12, 16
- Card padding: p-4 to p-6
- Section spacing: gap-6 to gap-8
- Button padding: px-4 py-2
- Modal padding: p-8

**Container Strategy:**
- Main menu: Centered, max-w-4xl
- Teams page: max-w-6xl with grid layout
- Team editor: max-w-7xl, 3x2 grid for 6 Pokémon slots
- Popups: max-w-4xl centered modal

---

## Component Library

### Navigation & Layout
**Main Menu:**
- Centered vertical layout with prominent "Teams" button
- Clean card container with shadow
- Button: Large, rounded-lg, full width within container

**Teams Page Header:**
- Flexbox row with "Teams" title on left
- "Create New Team" button on right (initially)
- Button moves below team cards after first team created

### Team Display Cards
**Team Card Structure:**
- Rounded-lg border with subtle shadow
- Team name at top (text-xl, bold)
- Grid of 6 Pokémon sprites (grid-cols-6, responsive to grid-cols-3 on mobile)
- Each sprite: 64x64px, centered in its cell
- Hover state: slight scale and shadow increase
- Empty slots: Dashed border placeholder

### Team Editor - Pokémon Slots
**6-Slot Grid:**
- 3x2 grid on desktop (grid-cols-3 gap-6)
- 2x3 on tablet (grid-cols-2)
- 1x6 on mobile (grid-cols-1)

**Individual Slot Card:**
- Border rounded-xl with elevation
- Header section: Pokemon nickname (editable inline) + species search dropdown
- Main content area divided into two columns:
  - Left: Sprite (96x96px minimum, centered)
  - Right: 4 move slots stacked vertically
- Bottom: Stats editor section

**Species Search Dropdown:**
- Small, unobtrusive trigger (text-sm with dropdown icon)
- Positioned in top-right of slot card header
- Dropdown: Absolute positioned, z-50, max-h-60 with scroll
- Search input: Sticky at top of dropdown
- Results: List items with hover states

### Move Slots
**Move Box Structure:**
- Height: h-16, rounded-lg
- Background: Pokémon type color (functional, not design choice)
- Flex layout: Move name on left, power/accuracy on right
- Empty state: Dashed border, "+ Add Move" text
- Click reveals search dropdown similar to species search

**Move Display:**
- Move name: text-base, white text on colored bg
- Power/Accuracy: text-xs, opacity-90, format "PWR 90 | ACC 100"
- Type colors override the "no color" rule as they're functional data visualization

### Expanded Popup Modal
**Modal Structure:**
- Overlay: Fixed, backdrop blur
- Modal card: Centered, max-w-4xl, rounded-2xl
- Close button: Top-right, large clickable area
- Layout: Same as slot card but expanded with more spacing
- Additional sections: Full stats display, abilities list

**Stats Editor Section:**
- Grid layout: 3 columns (HP, Atk, Def / SpA, SpD, Spe)
- Each stat: Label + numeric display
- Stat bars: Visual representation with filled bars
- Responsive: Stacks to 2 columns on tablet, 1 on mobile

### Forms & Inputs
**Search Inputs:**
- Border with focus ring
- Placeholder text with icon (search icon from Heroicons)
- Autocomplete dropdown: Clean list with hover states

**Text Inputs (Nickname/Team Name):**
- Subtle border, focus state with ring
- Clear visual hierarchy between label and input

---

## Responsive Behavior

**Breakpoints:**
- Mobile: < 640px (single column)
- Tablet: 640px - 1024px (2 columns)
- Desktop: > 1024px (3 columns for slots)

**Key Adaptations:**
- Pokémon slot grid collapses progressively
- Team sprite grids adjust from 6 to 3 to 2 columns
- Modal popups: Full screen on mobile with slide-up animation
- Search dropdowns: Full width on mobile

---

## Icons
**Library:** Heroicons (via CDN)
- Search icon for search inputs
- Close/X icon for modals
- Plus icon for empty slots
- Chevron for dropdowns

---

## Interaction Patterns
- Click slot → Modal opens with fade + scale animation
- Search typing → Dropdown appears below with slide-down
- Move/Pokémon selection → Instant update, no page reload
- Hover states: Subtle scale (1.02) and shadow increase
- Loading states: Spinner when fetching from PokéAPI

---

## Data Display Conventions
- Empty slots: Dashed borders with centered "+ Add Pokémon" text
- Loading sprites: Skeleton placeholder box
- Move slots: Type color backgrounds (Functional requirement)
- Stats: Horizontal bars with percentage fill based on base stats
- Abilities: Comma-separated list with subtle badges

---

## Images
No hero images needed. All visuals are functional sprites from PokéAPI displayed within cards and slots.