import { pgTable, text, varchar, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Pokemon Move Schema
export const moveSchema = z.object({
  name: z.string(),
  type: z.string(),
  power: z.number().nullable(),
  accuracy: z.number().nullable(),
});

export type Move = z.infer<typeof moveSchema>;

// Pokemon Stats Schema
export const statsSchema = z.object({
  hp: z.number(),
  attack: z.number(),
  defense: z.number(),
  specialAttack: z.number(),
  specialDefense: z.number(),
  speed: z.number(),
});

export type Stats = z.infer<typeof statsSchema>;

// Individual Values (IVs) Schema - 0-31 per stat
export const ivsSchema = z.object({
  hp: z.number().min(0).max(31).default(31),
  attack: z.number().min(0).max(31).default(31),
  defense: z.number().min(0).max(31).default(31),
  specialAttack: z.number().min(0).max(31).default(31),
  specialDefense: z.number().min(0).max(31).default(31),
  speed: z.number().min(0).max(31).default(31),
});

export type IVs = z.infer<typeof ivsSchema>;

// Pokemon Schema with fixed 4-slot moves structure
export const pokemonSchema = z.object({
  nickname: z.string().default(""),
  species: z.string().default(""),
  speciesId: z.number().nullable().default(null),
  sprite: z.string().default(""),
  moves: z.array(moveSchema.nullable()).max(4).default([]),
  stats: statsSchema.nullable().default(null),
  ivs: ivsSchema.default({
    hp: 31,
    attack: 31,
    defense: 31,
    specialAttack: 31,
    specialDefense: 31,
    speed: 31,
  }),
  abilities: z.array(z.string()).default([]),
  learnableMoves: z.array(z.string()).default([]),
});

export type Pokemon = z.infer<typeof pokemonSchema>;

// Team Table
export const teams = pgTable("teams", {
  id: varchar("id").primaryKey(),
  name: text("name").notNull(),
  pokemon: jsonb("pokemon").$type<Pokemon[]>().notNull().default([]),
});

// Insert and Select Schemas
export const insertTeamSchema = createInsertSchema(teams).omit({
  id: true,
});

export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Team = typeof teams.$inferSelect;
