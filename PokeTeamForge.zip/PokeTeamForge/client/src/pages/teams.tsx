import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Plus, ArrowLeft } from "lucide-react";
import type { Team } from "@shared/schema";

export default function Teams() {
  const [, setLocation] = useLocation();
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [teamName, setTeamName] = useState("");

  const { data: teams, isLoading } = useQuery<Team[]>({
    queryKey: ["/api/teams"],
  });

  const createTeamMutation = useMutation({
    mutationFn: async (name: string) => {
      const emptyPokemon = Array(6).fill(null).map(() => ({
        nickname: "",
        species: "",
        speciesId: null,
        sprite: "",
        moves: [null, null, null, null],
        stats: null,
        ivs: {
          hp: 31,
          attack: 31,
          defense: 31,
          specialAttack: 31,
          specialDefense: 31,
          speed: 31,
        },
        abilities: [],
        learnableMoves: [],
      }));
      
      return apiRequest("POST", "/api/teams", {
        name,
        pokemon: emptyPokemon,
      });
    },
    onSuccess: (newTeam: Team) => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
      setShowCreateDialog(false);
      setTeamName("");
      setLocation(`/team/${newTeam.id}`);
    },
  });

  const handleCreateTeam = () => {
    if (teamName.trim()) {
      createTeamMutation.mutate(teamName);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-6xl mx-auto space-y-6">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-3xl font-bold">Teams</h1>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-muted rounded" />
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-6 gap-2">
                    {[1, 2, 3, 4, 5, 6].map((j) => (
                      <div key={j} className="h-16 bg-muted rounded" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const hasTeams = teams && teams.length > 0;

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <h1 className="text-3xl font-bold">Teams</h1>
          </div>
          {!hasTeams && (
            <Button 
              onClick={() => setShowCreateDialog(true)}
              data-testid="button-create-team"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create New Team
            </Button>
          )}
        </div>

        {teams && teams.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {teams.map((team) => (
              <Link key={team.id} href={`/team/${team.id}`}>
                <Card className="hover-elevate cursor-pointer transition-all" data-testid={`card-team-${team.id}`}>
                  <CardHeader>
                    <CardTitle className="text-xl" data-testid={`text-team-name-${team.id}`}>
                      {team.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-6 gap-2">
                      {team.pokemon.map((pokemon, idx) => (
                        <div 
                          key={idx} 
                          className="aspect-square bg-muted rounded flex items-center justify-center overflow-hidden"
                          data-testid={`img-pokemon-sprite-${idx}`}
                        >
                          {pokemon.sprite ? (
                            <img 
                              src={pokemon.sprite} 
                              alt={pokemon.species || `Slot ${idx + 1}`}
                              className="w-full h-full object-contain pixelated"
                              style={{ imageRendering: 'pixelated' }}
                            />
                          ) : (
                            <div className="w-full h-full border-2 border-dashed border-border" />
                          )}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <Card className="p-12">
            <div className="text-center space-y-4">
              <h2 className="text-xl font-semibold text-muted-foreground">No teams yet</h2>
              <p className="text-muted-foreground">Create your first team to get started</p>
            </div>
          </Card>
        )}

        {hasTeams && (
          <div className="flex justify-center">
            <Button 
              onClick={() => setShowCreateDialog(true)}
              size="lg"
              data-testid="button-create-team"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create New Team
            </Button>
          </div>
        )}
      </div>

      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent data-testid="dialog-create-team">
          <DialogHeader>
            <DialogTitle>Create New Team</DialogTitle>
            <DialogDescription>
              Give your team a name to get started
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="team-name">Team Name</Label>
              <Input
                id="team-name"
                placeholder="Enter team name"
                value={teamName}
                onChange={(e) => setTeamName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleCreateTeam();
                  }
                }}
                data-testid="input-team-name"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowCreateDialog(false);
                setTeamName("");
              }}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreateTeam}
              disabled={!teamName.trim() || createTeamMutation.isPending}
              data-testid="button-create"
            >
              {createTeamMutation.isPending ? "Creating..." : "Create Team"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
