import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function Home() {
  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-2 text-center">
          <CardTitle className="text-3xl font-bold">Pokémon Team Builder</CardTitle>
          <CardDescription className="text-base">
            Build and customize your perfect Pokémon team
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Link href="/teams">
            <Button 
              size="lg" 
              className="w-full" 
              data-testid="button-teams"
            >
              View Teams
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
