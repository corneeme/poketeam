import { useState } from "react";
import { useParams, Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Edit2, Check } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { PokemonSlot } from "@/components/pokemon-slot";
import { PokemonModal } from "@/components/pokemon-modal";
import type { Team, Pokemon } from "@shared/schema";

export default function TeamEditor() {
  const { id } = useParams<{ id: string }>();
  const [editingName, setEditingName] = useState(false);
  const [teamName, setTeamName] = useState("");
  const [selectedSlot, setSelectedSlot] = useState<number | null>(null);

  const { data: team, isLoading } = useQuery<Team>({
    queryKey: ["/api/teams", id],
    enabled: !!id,
  });

  const updateTeamMutation = useMutation({
    mutationFn: async (updates: Partial<Team>) => {
      return apiRequest("PATCH", `/api/teams/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/teams", id] });
      queryClient.invalidateQueries({ queryKey: ["/api/teams"] });
    },
  });

  const handleUpdatePokemon = (index: number, pokemon: Pokemon) => {
    if (!team) return;
    const updatedPokemon = [...team.pokemon];
    updatedPokemon[index] = pokemon;
    updateTeamMutation.mutate({ pokemon: updatedPokemon });
  };

  const handleSaveName = () => {
    if (teamName.trim()) {
      updateTeamMutation.mutate({ name: teamName });
      setEditingName(false);
    }
  };

  if (isLoading || !team) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex items-center gap-4">
            <Link href="/teams">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div className="h-8 bg-muted rounded w-48 animate-pulse" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="p-6 h-96 animate-pulse" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="flex items-center gap-4 flex-wrap">
            <Link href="/teams">
              <Button variant="ghost" size="icon" data-testid="button-back">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            {editingName ? (
              <div className="flex items-center gap-2 flex-1 max-w-md">
                <Input
                  value={teamName}
                  onChange={(e) => setTeamName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") handleSaveName();
                    if (e.key === "Escape") setEditingName(false);
                  }}
                  autoFocus
                  data-testid="input-team-name"
                />
                <Button
                  size="icon"
                  onClick={handleSaveName}
                  data-testid="button-save-name"
                >
                  <Check className="w-4 h-4" />
                </Button>
              </div>
            ) : (
              <>
                <h1 className="text-3xl font-bold" data-testid="text-team-name">
                  {team.name}
                </h1>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setTeamName(team.name);
                    setEditingName(true);
                  }}
                  data-testid="button-edit-name"
                >
                  <Edit2 className="w-4 h-4" />
                </Button>
              </>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {team.pokemon.map((pokemon, index) => (
              <PokemonSlot
                key={index}
                pokemon={pokemon}
                slotIndex={index}
                onUpdate={(updatedPokemon) => handleUpdatePokemon(index, updatedPokemon)}
                onClick={() => setSelectedSlot(index)}
              />
            ))}
          </div>
        </div>
      </div>

      {selectedSlot !== null && (
        <PokemonModal
          pokemon={team.pokemon[selectedSlot]}
          slotIndex={selectedSlot}
          onUpdate={(updatedPokemon) => {
            handleUpdatePokemon(selectedSlot, updatedPokemon);
          }}
          onClose={() => setSelectedSlot(null)}
        />
      )}
    </>
  );
}
