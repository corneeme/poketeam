import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, ChevronDown, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface SpeciesSearchProps {
  onSelect: (species: {
    name: string;
    id: number;
    sprite: string;
    moves: (any | null)[];
    stats: any;
    abilities: string[];
    learnableMoves: string[];
  }) => void;
  currentSpecies?: string;
  fullWidth?: boolean;
}

export function SpeciesSearch({ onSelect, currentSpecies = "", fullWidth = false }: SpeciesSearchProps) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [species, setSpecies] = useState<{ name: string; url: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [fetchingDetails, setFetchingDetails] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    setLoading(true);
    fetch("https://pokeapi.co/api/v2/pokemon?limit=1025")
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch Pokémon list");
        return res.json();
      })
      .then((data) => {
        setSpecies(data.results);
        setError(null);
      })
      .catch((err) => {
        setError(err.message);
        toast({
          title: "Error",
          description: "Failed to load Pokémon list. Please try again.",
          variant: "destructive",
        });
      })
      .finally(() => setLoading(false));
  }, []);

  const filteredSpecies = species.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase())
  ).slice(0, 50);

  const handleSelect = async (pokemonName: string) => {
    setFetchingDetails(true);
    try {
      const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokemonName}`);
      if (!response.ok) throw new Error("Failed to fetch Pokémon details");
      
      const data = await response.json();

      const stats = {
        hp: data.stats[0].base_stat,
        attack: data.stats[1].base_stat,
        defense: data.stats[2].base_stat,
        specialAttack: data.stats[3].base_stat,
        specialDefense: data.stats[4].base_stat,
        speed: data.stats[5].base_stat,
      };

      const abilities = data.abilities.map((a: any) => a.ability.name);
      const learnableMoves = data.moves.map((m: any) => m.move.name);

      onSelect({
        name: pokemonName,
        id: data.id,
        sprite: data.sprites.front_default || "",
        moves: [null, null, null, null],
        stats,
        abilities,
        learnableMoves,
      });

      setOpen(false);
      setSearch("");
    } catch (error) {
      console.error("Failed to fetch Pokémon details:", error);
      toast({
        title: "Error",
        description: `Failed to load ${pokemonName}. Please try again.`,
        variant: "destructive",
      });
    } finally {
      setFetchingDetails(false);
    }
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn(
            "justify-between",
            fullWidth ? "w-full" : "w-auto",
            !currentSpecies && "text-muted-foreground"
          )}
          data-testid="button-species-search"
        >
          <span className="truncate">
            {currentSpecies
              ? currentSpecies.charAt(0).toUpperCase() + currentSpecies.slice(1)
              : "Select species"}
          </span>
          <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[300px] p-0" align={fullWidth ? "start" : "end"}>
        <div className="flex items-center border-b px-3 py-2">
          <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
          <Input
            placeholder="Search Pokémon..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="border-0 p-0 focus-visible:ring-0"
            data-testid="input-species-search"
          />
        </div>
        <ScrollArea className="h-[300px]">
          {loading || fetchingDetails ? (
            <div className="flex items-center justify-center py-6">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : error ? (
            <div className="py-6 text-center text-sm text-destructive">
              {error}
            </div>
          ) : filteredSpecies.length === 0 ? (
            <div className="py-6 text-center text-sm text-muted-foreground">
              {search ? "No Pokémon found" : "Start typing to search"}
            </div>
          ) : (
            <div className="p-1">
              {filteredSpecies.map((s) => (
                <button
                  key={s.name}
                  onClick={() => handleSelect(s.name)}
                  className="w-full text-left px-3 py-2 text-sm rounded hover-elevate transition-colors"
                  data-testid={`button-select-${s.name}`}
                >
                  {s.name.charAt(0).toUpperCase() + s.name.slice(1)}
                </button>
              ))}
            </div>
          )}
        </ScrollArea>
      </PopoverContent>
    </Popover>
  );
}
