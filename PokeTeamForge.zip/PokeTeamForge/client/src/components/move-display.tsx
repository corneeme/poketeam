import { cn } from "@/lib/utils";
import type { Move } from "@shared/schema";

interface MoveDisplayProps {
  move: Move;
  compact?: boolean;
}

const TYPE_COLORS: Record<string, string> = {
  normal: "#A8A878",
  fire: "#F08030",
  water: "#6890F0",
  electric: "#F8D030",
  grass: "#78C850",
  ice: "#98D8D8",
  fighting: "#C03028",
  poison: "#A040A0",
  ground: "#E0C068",
  flying: "#A890F0",
  psychic: "#F85888",
  bug: "#A8B820",
  rock: "#B8A038",
  ghost: "#705898",
  dragon: "#7038F8",
  dark: "#705848",
  steel: "#B8B8D0",
  fairy: "#EE99AC",
};

export function MoveDisplay({ move, compact = false }: MoveDisplayProps) {
  const bgColor = TYPE_COLORS[move.type.toLowerCase()] || "#A8A878";
  const textColor = "#FFFFFF";

  return (
    <div
      className={cn(
        "rounded-lg px-3 flex items-center justify-between",
        compact ? "py-1" : "py-2"
      )}
      style={{ backgroundColor: bgColor }}
      data-testid="move-display"
    >
      <span 
        className={cn("font-medium truncate", compact ? "text-xs" : "text-sm")}
        style={{ color: textColor }}
      >
        {move.name.split('-').map(word => 
          word.charAt(0).toUpperCase() + word.slice(1)
        ).join(' ')}
      </span>
      <span 
        className={cn("text-xs opacity-90 ml-2 shrink-0")}
        style={{ color: textColor }}
      >
        {move.power ? `PWR ${move.power}` : "—"} | {move.accuracy ? `ACC ${move.accuracy}` : "—"}
      </span>
    </div>
  );
}
