import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Plus } from "lucide-react";
import { SpeciesSearch } from "@/components/species-search";
import { MoveDisplay } from "@/components/move-display";
import type { Pokemon } from "@shared/schema";

interface PokemonSlotProps {
  pokemon: Pokemon;
  slotIndex: number;
  onUpdate: (pokemon: Pokemon) => void;
  onClick: () => void;
}

export function PokemonSlot({ pokemon, slotIndex, onUpdate, onClick }: PokemonSlotProps) {
  const isEmpty = !pokemon.species;

  const handleNicknameChange = (nickname: string) => {
    onUpdate({ ...pokemon, nickname });
  };

  const handleSpeciesSelect = (speciesData: {
    name: string;
    id: number;
    sprite: string;
    stats: any;
    abilities: string[];
    learnableMoves: string[];
  }) => {
    onUpdate({
      ...pokemon,
      species: speciesData.name,
      speciesId: speciesData.id,
      sprite: speciesData.sprite,
      stats: speciesData.stats,
      abilities: speciesData.abilities,
      learnableMoves: speciesData.learnableMoves,
      nickname: pokemon.nickname || speciesData.name.charAt(0).toUpperCase() + speciesData.name.slice(1),
    });
  };

  return (
    <Card 
      className="hover-elevate cursor-pointer transition-all"
      onClick={onClick}
      data-testid={`card-pokemon-slot-${slotIndex}`}
    >
      <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-3">
        <Input
          value={pokemon.nickname}
          onChange={(e) => {
            e.stopPropagation();
            handleNicknameChange(e.target.value);
          }}
          onClick={(e) => e.stopPropagation()}
          placeholder={`Pokémon ${slotIndex + 1}`}
          className="text-base font-semibold h-8"
          data-testid={`input-nickname-${slotIndex}`}
        />
        <SpeciesSearch
          onSelect={handleSpeciesSelect}
          currentSpecies={pokemon.species}
        />
      </CardHeader>
      <CardContent className="space-y-4">
        {isEmpty ? (
          <div className="flex flex-col items-center justify-center py-8 space-y-3">
            <div className="w-24 h-24 rounded-lg border-2 border-dashed border-border flex items-center justify-center">
              <Plus className="w-8 h-8 text-muted-foreground" />
            </div>
            <p className="text-sm text-muted-foreground">Select a Pokémon</p>
          </div>
        ) : (
          <>
            <div className="flex items-start gap-4">
              <div className="w-24 h-24 bg-muted rounded-lg flex items-center justify-center overflow-hidden flex-shrink-0">
                {pokemon.sprite && (
                  <img
                    src={pokemon.sprite}
                    alt={pokemon.species}
                    className="w-full h-full object-contain pixelated"
                    style={{ imageRendering: 'pixelated' }}
                    data-testid={`img-sprite-${slotIndex}`}
                  />
                )}
              </div>
              <div className="flex-1 space-y-2 min-w-0">
                <p className="text-sm font-medium text-muted-foreground">
                  {pokemon.species.charAt(0).toUpperCase() + pokemon.species.slice(1)}
                </p>
                <div className="space-y-1">
                  {pokemon.moves.filter((m): m is NonNullable<typeof m> => m !== null).slice(0, 2).map((move, idx) => (
                    <MoveDisplay key={idx} move={move} compact />
                  ))}
                  {pokemon.moves.filter(m => m !== null).length > 2 && (
                    <p className="text-xs text-muted-foreground">
                      +{pokemon.moves.filter(m => m !== null).length - 2} more
                    </p>
                  )}
                  {pokemon.moves.filter(m => m !== null).length === 0 && (
                    <p className="text-xs text-muted-foreground">No moves selected</p>
                  )}
                </div>
              </div>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
