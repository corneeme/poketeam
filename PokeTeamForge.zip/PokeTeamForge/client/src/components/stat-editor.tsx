import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { HexagonStatChart } from "@/components/hexagon-stat-chart";
import type { Stats, IVs } from "@shared/schema";

interface StatEditorProps {
  stats: Stats | null;
  ivs: IVs;
  onIVsChange?: (ivs: IVs) => void;
}

const STAT_NAMES = {
  hp: "HP",
  attack: "Attack",
  defense: "Defense",
  specialAttack: "Sp. Atk",
  specialDefense: "Sp. Def",
  speed: "Speed",
};

export function StatEditor({ stats, ivs, onIVsChange }: StatEditorProps) {
  // Guard against null stats
  if (!stats) {
    return (
      <div className="flex items-center justify-center py-8 text-center text-muted-foreground">
        <p>Select a Pokémon species to view stats</p>
      </div>
    );
  }
  const handleIVChange = (stat: keyof IVs, value: string) => {
    if (!onIVsChange) return;
    
    const numValue = parseInt(value, 10);
    if (isNaN(numValue)) return;
    
    const clampedValue = Math.max(0, Math.min(31, numValue));
    onIVsChange({
      ...ivs,
      [stat]: clampedValue,
    });
  };

  return (
    <div className="space-y-6">
      {/* Hexagon Chart */}
      <div className="flex justify-center">
        <HexagonStatChart stats={stats} ivs={ivs} size={280} />
      </div>

      {/* IV Editor */}
      {onIVsChange && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label className="text-base font-semibold">Individual Values (IVs)</Label>
            <span className="text-xs text-muted-foreground">0-31 per stat</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {Object.entries(STAT_NAMES).map(([key, label]) => {
              const statKey = key as keyof IVs;
              const baseValue = stats[statKey];
              const ivValue = ivs[statKey];
              const totalValue = baseValue + ivValue;

              return (
                <div key={key} className="space-y-2" data-testid={`iv-editor-${key}`}>
                  <div className="flex justify-between items-center">
                    <Label htmlFor={`iv-${key}`} className="text-sm font-medium">
                      {label}
                    </Label>
                    <span className="text-xs font-mono text-muted-foreground">
                      {baseValue} + {ivValue} = {totalValue}
                    </span>
                  </div>
                  <Input
                    id={`iv-${key}`}
                    type="number"
                    min="0"
                    max="31"
                    value={ivValue}
                    onChange={(e) => handleIVChange(statKey, e.target.value)}
                    className="h-9"
                    data-testid={`input-iv-${key}`}
                  />
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Stat Summary Table */}
      <div className="space-y-2">
        <Label className="text-sm font-semibold text-muted-foreground">Stat Summary</Label>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {Object.entries(STAT_NAMES).map(([key, label]) => {
            const statKey = key as keyof Stats;
            const baseValue = stats[statKey];
            const ivValue = ivs[statKey];
            const totalValue = baseValue + ivValue;

            return (
              <div
                key={key}
                className="bg-muted/50 rounded-lg p-3 space-y-1"
                data-testid={`stat-summary-${key}`}
              >
                <div className="text-xs font-medium text-muted-foreground">{label}</div>
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold text-primary">{totalValue}</span>
                  <span className="text-xs text-muted-foreground">
                    ({baseValue}+{ivValue})
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
