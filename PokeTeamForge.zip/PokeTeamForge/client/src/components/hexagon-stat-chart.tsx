import { useMemo } from "react";
import type { Stats, IVs } from "@shared/schema";

interface HexagonStatChartProps {
  stats: Stats;
  ivs: IVs;
  maxBaseStat?: number;
  size?: number;
}

const STAT_NAMES = ["HP", "Attack", "Defense", "Sp. Atk", "Sp. Def", "Speed"] as const;
const STAT_KEYS: (keyof Stats)[] = ["hp", "attack", "defense", "specialAttack", "specialDefense", "speed"];

export function HexagonStatChart({ stats, ivs, maxBaseStat = 255, size = 200 }: HexagonStatChartProps) {
  const radius = size / 2;
  const center = { x: size / 2, y: size / 2 };

  // Use consistent max value for both base and IV-adjusted stats
  const maxStatValue = maxBaseStat + 31;

  // Calculate hexagon points for each stat value
  const getHexagonPoints = (statValues: number[]) => {
    return STAT_KEYS.map((key, index) => {
      const value = statValues[index];
      const normalizedValue = Math.min(value / maxStatValue, 1);
      const angle = (Math.PI / 3) * index - Math.PI / 2; // Start from top
      const distance = normalizedValue * (radius - 20); // Leave margin
      
      return {
        x: center.x + distance * Math.cos(angle),
        y: center.y + distance * Math.sin(angle),
      };
    });
  };

  // Background hexagon grid
  const gridLevels = [0.2, 0.4, 0.6, 0.8, 1.0];
  const gridPaths = gridLevels.map((level) => {
    const points = STAT_KEYS.map((_, index) => {
      const angle = (Math.PI / 3) * index - Math.PI / 2;
      const distance = level * (radius - 20);
      return {
        x: center.x + distance * Math.cos(angle),
        y: center.y + distance * Math.sin(angle),
      };
    });
    return points.map(p => `${p.x},${p.y}`).join(" ");
  });

  // Base stats hexagon (filled)
  const baseStatValues = STAT_KEYS.map(key => stats[key]);
  const baseStatPoints = getHexagonPoints(baseStatValues);
  const baseStatPath = baseStatPoints.map(p => `${p.x},${p.y}`).join(" ");

  // IV-adjusted stats hexagon (outline)
  const ivAdjustedValues = STAT_KEYS.map(key => stats[key] + ivs[key]);
  const ivStatPoints = getHexagonPoints(ivAdjustedValues);
  const ivStatPath = ivStatPoints.map(p => `${p.x},${p.y}`).join(" ");

  // Axis lines and labels
  const axes = STAT_KEYS.map((key, index) => {
    const angle = (Math.PI / 3) * index - Math.PI / 2;
    const labelDistance = radius - 5;
    const labelX = center.x + labelDistance * Math.cos(angle);
    const labelY = center.y + labelDistance * Math.sin(angle);

    // Adjust text anchor based on position
    let textAnchor: "start" | "middle" | "end" = "middle";
    if (labelX < center.x - 10) textAnchor = "end";
    else if (labelX > center.x + 10) textAnchor = "start";

    const dy = labelY < center.y ? "-0.5em" : labelY > center.y ? "1em" : "0.3em";

    return {
      line: `${center.x},${center.y} ${center.x + (radius - 20) * Math.cos(angle)},${center.y + (radius - 20) * Math.sin(angle)}`,
      label: {
        x: labelX,
        y: labelY,
        text: STAT_NAMES[index],
        textAnchor,
        dy,
      },
      value: {
        base: baseStatValues[index],
        iv: ivs[key as keyof IVs],
      },
    };
  });

  return (
    <div className="relative">
      <svg width={size} height={size} className="overflow-visible">
        {/* Grid lines */}
        {gridPaths.map((path, i) => (
          <polyline
            key={i}
            points={path}
            fill="none"
            stroke="hsl(var(--border))"
            strokeWidth="1"
            opacity={0.3}
          />
        ))}

        {/* Axis lines */}
        {axes.map((axis, i) => (
          <line
            key={i}
            x1={center.x}
            y1={center.y}
            x2={axis.line.split(" ")[1].split(",")[0]}
            y2={axis.line.split(" ")[1].split(",")[1]}
            stroke="hsl(var(--border))"
            strokeWidth="1"
            opacity={0.3}
          />
        ))}

        {/* Base stats hexagon (filled) */}
        <polyline
          points={baseStatPath}
          fill="hsl(var(--primary) / 0.2)"
          stroke="hsl(var(--primary))"
          strokeWidth="2"
        />

        {/* IV-adjusted stats hexagon (outline only) */}
        <polyline
          points={ivStatPath}
          fill="hsl(var(--accent) / 0.1)"
          stroke="hsl(var(--accent))"
          strokeWidth="2.5"
          strokeDasharray="4 2"
        />

        {/* Stat labels */}
        {axes.map((axis, i) => (
          <text
            key={i}
            x={axis.label.x}
            y={axis.label.y}
            textAnchor={axis.label.textAnchor}
            dy={axis.label.dy}
            className="text-xs font-semibold fill-foreground"
          >
            {axis.label.text}
          </text>
        ))}

        {/* Stat value points */}
        {ivStatPoints.map((point, i) => (
          <circle
            key={i}
            cx={point.x}
            cy={point.y}
            r="4"
            fill="hsl(var(--accent))"
            stroke="hsl(var(--accent-foreground))"
            strokeWidth="1"
          />
        ))}
        {baseStatPoints.map((point, i) => (
          <circle
            key={i}
            cx={point.x}
            cy={point.y}
            r="3"
            fill="hsl(var(--primary))"
          />
        ))}
      </svg>

      {/* Legend */}
      <div className="mt-4 flex gap-6 justify-center text-xs">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-sm bg-primary/20 border-2 border-primary" />
          <span className="text-muted-foreground">Base Stats</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-sm bg-accent/10 border-2 border-accent border-dashed" />
          <span className="text-muted-foreground">With IVs</span>
        </div>
      </div>
    </div>
  );
}
