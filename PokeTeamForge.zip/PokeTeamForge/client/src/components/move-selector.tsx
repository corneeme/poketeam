import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MoveDisplay } from "@/components/move-display";
import { useToast } from "@/hooks/use-toast";
import { Plus, X, Search, Loader2 } from "lucide-react";
import type { Move } from "@shared/schema";

interface MoveSelectorProps {
  moves: (Move | null)[];
  learnableMoves: string[];
  onUpdate: (moves: (Move | null)[]) => void;
  slotIndex: number;
}

export function MoveSelector({ moves, learnableMoves, onUpdate, slotIndex }: MoveSelectorProps) {
  const [openSlot, setOpenSlot] = useState<number | null>(null);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const filteredMoves = learnableMoves
    .filter((m) => m.toLowerCase().includes(search.toLowerCase()))
    .slice(0, 50);

  const handleSelectMove = async (moveName: string, slot: number) => {
    setLoading(true);
    try {
      const response = await fetch(`https://pokeapi.co/api/v2/move/${moveName}`);
      if (!response.ok) throw new Error("Failed to fetch move details");
      
      const data = await response.json();

      const newMove: Move = {
        name: moveName,
        type: data.type.name,
        power: data.power,
        accuracy: data.accuracy,
      };

      const updatedSlots = Array(4).fill(null).map((_, idx) => moves[idx] ?? null);
      updatedSlots[slot] = newMove;
      onUpdate(updatedSlots);

      setOpenSlot(null);
      setSearch("");
    } catch (error) {
      console.error("Failed to fetch move details:", error);
      toast({
        title: "Error",
        description: `Failed to load ${moveName}. Please try again.`,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleRemoveMove = (slot: number) => {
    const updatedSlots = Array(4).fill(null).map((_, idx) => moves[idx] ?? null);
    updatedSlots[slot] = null;
    onUpdate(updatedSlots);
  };

  const slots = Array(4).fill(null).map((_, idx) => moves[idx] ?? null);

  return (
    <div className="space-y-2">
      {slots.map((move, idx) => (
        <div key={idx} className="relative">
          {move ? (
            <div className="relative group">
              <MoveDisplay move={move} />
              <Button
                variant="ghost"
                size="icon"
                className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-destructive text-destructive-foreground opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => handleRemoveMove(idx)}
                data-testid={`button-remove-move-${slotIndex}-${idx}`}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          ) : (
            <Popover open={openSlot === idx} onOpenChange={(open) => setOpenSlot(open ? idx : null)}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full h-12 border-dashed justify-center"
                  data-testid={`button-add-move-${slotIndex}-${idx}`}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Move {idx + 1}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[300px] p-0" align="start">
                <div className="flex items-center border-b px-3 py-2">
                  <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
                  <Input
                    placeholder="Search moves..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="border-0 p-0 focus-visible:ring-0"
                    data-testid={`input-move-search-${slotIndex}-${idx}`}
                  />
                </div>
                <ScrollArea className="h-[300px]">
                  {loading ? (
                    <div className="flex items-center justify-center py-6">
                      <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                    </div>
                  ) : filteredMoves.length === 0 ? (
                    <div className="py-6 text-center text-sm text-muted-foreground">
                      {learnableMoves.length === 0 ? "Select a Pokémon first" : "No moves found"}
                    </div>
                  ) : (
                    <div className="p-1">
                      {filteredMoves.map((moveName) => (
                        <button
                          key={moveName}
                          onClick={() => handleSelectMove(moveName, idx)}
                          className="w-full text-left px-3 py-2 text-sm rounded hover-elevate transition-colors"
                          data-testid={`button-select-move-${moveName}`}
                        >
                          {moveName.split('-').map(word => 
                            word.charAt(0).toUpperCase() + word.slice(1)
                          ).join(' ')}
                        </button>
                      ))}
                    </div>
                  )}
                </ScrollArea>
              </PopoverContent>
            </Popover>
          )}
        </div>
      ))}
    </div>
  );
}
