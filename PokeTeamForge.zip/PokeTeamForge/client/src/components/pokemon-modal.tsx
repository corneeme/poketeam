import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { SpeciesSearch } from "@/components/species-search";
import { MoveSelector } from "@/components/move-selector";
import { StatEditor } from "@/components/stat-editor";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import type { Pokemon } from "@shared/schema";

interface PokemonModalProps {
  pokemon: Pokemon;
  slotIndex: number;
  onUpdate: (pokemon: Pokemon) => void;
  onClose: () => void;
}

export function PokemonModal({ pokemon, slotIndex, onUpdate, onClose }: PokemonModalProps) {
  const [localPokemon, setLocalPokemon] = useState(pokemon);
  const { toast } = useToast();

  useEffect(() => {
    setLocalPokemon(pokemon);
  }, [pokemon]);

  const handleUpdate = (updates: Partial<Pokemon>) => {
    const updated = { ...localPokemon, ...updates };
    setLocalPokemon(updated);
  };

  const handleSave = () => {
    onUpdate(localPokemon);
  };

  const handleSpeciesSelect = (speciesData: {
    name: string;
    id: number;
    sprite: string;
    moves: (any | null)[];
    stats: any;
    abilities: string[];
    learnableMoves: string[];
  }) => {
    const updated = {
      species: speciesData.name,
      speciesId: speciesData.id,
      sprite: speciesData.sprite,
      stats: speciesData.stats,
      abilities: speciesData.abilities,
      learnableMoves: speciesData.learnableMoves,
      nickname: localPokemon.nickname || speciesData.name.charAt(0).toUpperCase() + speciesData.name.slice(1),
      moves: speciesData.moves,
    };
    handleUpdate(updated);
    onUpdate({ ...localPokemon, ...updated });
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh]" data-testid={`dialog-pokemon-${slotIndex}`}>
        <DialogHeader>
          <DialogTitle>
            Edit Pokémon - Slot {slotIndex + 1}
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="max-h-[calc(90vh-8rem)] pr-4">
          <div className="space-y-6 pb-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="nickname">Nickname</Label>
                <Input
                  id="nickname"
                  value={localPokemon.nickname}
                  onChange={(e) => handleUpdate({ nickname: e.target.value })}
                  onBlur={handleSave}
                  placeholder="Enter nickname"
                  data-testid={`input-nickname-modal-${slotIndex}`}
                />
              </div>
              <div className="space-y-2">
                <Label>Species</Label>
                <SpeciesSearch
                  onSelect={handleSpeciesSelect}
                  currentSpecies={localPokemon.species}
                  fullWidth
                />
              </div>
            </div>

            {localPokemon.species && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-center">
                      <div className="w-32 h-32 bg-muted rounded-lg flex items-center justify-center overflow-hidden">
                        {localPokemon.sprite && (
                          <img
                            src={localPokemon.sprite}
                            alt={localPokemon.species}
                            className="w-full h-full object-contain pixelated"
                            style={{ imageRendering: 'pixelated' }}
                            data-testid={`img-sprite-modal-${slotIndex}`}
                          />
                        )}
                      </div>
                    </div>

                    {localPokemon.abilities.length > 0 && (
                      <div className="space-y-2">
                        <Label>Abilities</Label>
                        <div className="flex flex-wrap gap-2">
                          {localPokemon.abilities.map((ability, idx) => (
                            <Badge key={idx} variant="secondary" data-testid={`badge-ability-${idx}`}>
                              {ability.split('-').map(word => 
                                word.charAt(0).toUpperCase() + word.slice(1)
                              ).join(' ')}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    <Label>Moves</Label>
                    <MoveSelector
                      moves={localPokemon.moves}
                      learnableMoves={localPokemon.learnableMoves}
                      onUpdate={(moves) => {
                        handleUpdate({ moves });
                        onUpdate({ ...localPokemon, moves });
                      }}
                      slotIndex={slotIndex}
                    />
                  </div>
                </div>

                {localPokemon.stats && (
                  <div className="space-y-2">
                    <Label>Stats</Label>
                    <StatEditor 
                      stats={localPokemon.stats} 
                      ivs={localPokemon.ivs}
                      onIVsChange={(ivs) => {
                        handleUpdate({ ivs });
                        onUpdate({ ...localPokemon, ivs });
                      }}
                    />
                  </div>
                )}
              </>
            )}

            {!localPokemon.species && (
              <div className="py-12 text-center text-muted-foreground">
                <p>Select a Pokémon species to get started</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}
